import './App.css';
import DataEntryForm from './components/DataEntryForm';

function App() {
  return (
    <div className="App">
      <DataEntryForm/>
    </div>
  );
}

export default App;
